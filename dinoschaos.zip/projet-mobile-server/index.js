
const express = require('express');
const socketIO = require('socket.io');

const PORT = process.env.PORT || 3000;
const INDEX = '/index.html';

const server = express().use(express.static("public"))
  .listen(PORT, () => console.log(`Listening on ${PORT}`));


const io = socketIO(server);
var tab_room = [];

//connexion
io.on('connection',(socket)=>{

    console.log("new connection");
    io.to(socket.id).emit('con');

    //deconnexion
    socket.on('disconnect',()=>{
        //on enelve les joueurs de la game et supprime les partie finis
        for(var i = 0; i < tab_room.length;i++){
            if(tab_room[i].j2.id == socket.id){
                tab_room[i].j2.id = null;
                tab_room[i].j2.ready = false;
                tab_room[i].j1.ready = false;
                io.to(tab_room[i].j1.id).emit('disconnection');
            }
            if(tab_room[i].j1.id == socket.id){
                tab_room[i].j1.id = null;
                tab_room[i].j2.ready = false;
                tab_room[i].j1.ready = false;
                io.to(tab_room[i].j2.id).emit('disconnection');
            }
            if(tab_room[i].j1.id == null && tab_room[i].j2.id == null){
                console.log("game delete : "+ tab_room[i].id );
                tab_room.splice(i,1);
            }
        }
    });

    //reconnexion
    socket.on('reco',(id_room)=>{
        console.log("reconnect : "+ id_room );
        for(var i = 0; i < tab_room.length;i++){
          if(tab_room[i].id === id_room){
            if(tab_room[i].j1.id === null){
                tab_room[i].j1.id = socket.id;
                io.to(tab_room[i].j2.id).emit('reco');
                break;
            }
             if(tab_room[i].j2.id === null){
                tab_room[i].j2.id = socket.id;
                io.to(tab_room[i].j1.id).emit('reco');
                break;
            }
          }
        }
    });

    socket.on('reconnect_data',(id_room,score,role,money,life,obstacle)=>{
        
        console.log("reconnect_data : "+ id_room );
        for(var i = 0; i < tab_room.length;i++){
          if(tab_room[i].id === id_room){
            if(tab_room[i].j1.id === socket.id){
                io.to(tab_room[i].j2.id).emit('reconnect_data',id_room,score,role,money,life,obstacle);
                break;
            }
            if(tab_room[i].j2.id === socket.id){
                io.to(tab_room[i].j1.id).emit('reconnect_data',id_room,score,role,money,life,obstacle);
                break;
            } 
          }
        }
    });

    //creation d'une game
    socket.on('new_game',(mdp)=>{
        console.log("new_game : " + mdp);
        var err =0;
        for(var i = 0; i < tab_room.length;i++){
            if(tab_room[i].id === mdp){
                 io.to(socket.id).emit('warning',"Une partie avec cette identifiant existe déjà");
                 err = 1;
            }
        }
        if(err == 0){
            var room = new Object();
            room.id = mdp;
            room.mode = "private";
            room.j1 = {"id":socket.id,"ready":false};
            room.j2 = {"id":null,"ready":false};
            tab_room.push(room);
        }
    });

    
    socket.on('find_game',(a)=>{
        var found = false;
        for(var i = 0; i < tab_room.length;i++){
            if(tab_room[i].mode === "public" && tab_room[i].j1.id == null){
                tab_room[i].j1.id = socket.id;  
                var role_j1 = "Builder";
                var role_j2 = "Dino";
                if( Math.random() <= 0.5){
                    role_j1 = "Dino";
                    role_j2 = "Builder";
                }
                io.to(socket.id).emit('start_game',tab_room[i].id,role_j1);
                io.to(tab_room[i].j2.id).emit('start_game',tab_room[i].id,role_j2);
                found = true;
                break;
            }
            if(tab_room[i].mode === "public" && tab_room[i].j2.id == null){
                tab_room[i].j2.id = socket.id;  
                var role_j1 = "Builder";
                var role_j2 = "Dino";
                if( Math.random() <= 0.5){
                    role_j1 = "Dino";
                    role_j2 = "Builder";
                }
                io.to(socket.id).emit('start_game',tab_room[i].id,role_j1);
                io.to(tab_room[i].j1.id).emit('start_game',tab_room[i].id,role_j2);
                found = true;
                break;
            }
        }
        if(!found){
            var room = new Object();
            room.id = getRandomPass();
            room.mode = "public";
            room.j1 = {"id":socket.id,"ready":false};
            room.j2 = {"id":null,"ready":false};
            tab_room.push(room);
        }
    });

    socket.on('deleteGame',(a)=>{
        for(var i = 0; i < tab_room.length;i++){
            if(tab_room[i].mode === "public" && ( tab_room[i].j1.id == null ||  tab_room[i].j2.id == null) &&  ( tab_room[i].j1.id == socket.id ||  tab_room[i].j2.id == socket.id) ){
                console.log("game delete : "+ tab_room[i].id );
                tab_room.splice(i,1);
            }
        }     
    });

    socket.on("jump",(id)=>{
         for(var i = 0; i < tab_room.length;i++){
            if(tab_room[i].id === id ){
                io.to( tab_room[i].j1.id).to( tab_room[i].j2.id).emit('jump');
            }
        }
    })

    socket.on("life_lost",(id)=>{
    for(var i = 0; i < tab_room.length;i++){
        if(tab_room[i].id === id ){
            io.to( tab_room[i].j1.id).to( tab_room[i].j2.id).emit('life_lost');
        }
    }
    })

    socket.on("power",(id,power)=>{
    for(var i = 0; i < tab_room.length;i++){
        if(tab_room[i].id === id ){
            io.to( tab_room[i].j1.id).to( tab_room[i].j2.id).emit('power',power);
        }
    }
    })

    socket.on("end_game",(id)=>{
    for(var i = 0; i < tab_room.length;i++){
        if(tab_room[i].id === id ){
            console.log("game delete : "+ tab_room[i].id );
            tab_room.splice(i,1);
            break;
        }
    }
    })

    socket.on("new_obstacles",(id,obstacle)=>{
         for(var i = 0; i < tab_room.length;i++){
            if(tab_room[i].id === id ){
                io.to( tab_room[i].j1.id).to( tab_room[i].j2.id).emit('new_obstacles',obstacle);
            }
        }
    })

    socket.on("ready",(id)=>{
         for(var i = 0; i < tab_room.length;i++){
            if(tab_room[i].id === id ){
                if(tab_room[i].j1.id === socket.id){
                    tab_room[i].j1.ready = true;
                }else{
                    tab_room[i].j2.ready = true;
                }
                //lancement de la partie si les deux joueurs sont pret
                if( tab_room[i].j1.ready &&  tab_room[i].j2.ready){
                    io.to( tab_room[i].j1.id).to( tab_room[i].j2.id).emit('ready');
                }
            }
        }
    })

    //rejoindre une partie
    socket.on('join_game',(id)=>{
        var j =0;
        //recherche de la partie
        for(var i = 0; i < tab_room.length;i++){
            if(tab_room[i].id === id && tab_room[i].j2.id == null || tab_room[i].id === id && tab_room[i].j1.id == null){
                var role_j1 = "Builder";
                if( Math.random() <= 0.5){
                    role_j1 = "Dino";
                }
                if(tab_room[i].j2.id==null){
                    tab_room[i].j2.id = socket.id;
                    io.to( tab_room[i].j1.id).emit('start_game',tab_room[i].id,role_j1);
                }else{
                    tab_room[i].j1.id = socket.id;
                    io.to(tab_room[i].j2.id).emit('start_game',tab_room[i].id,role_j1);
                }
                var role = "Dino";
                if(role_j1 == "Dino"){
                    role = "Builder";
                }
                //lancement de la partie
                io.to(socket.id).emit('start_game',tab_room[i].id,role);
                j = 1;
            }
        }
        if(j == 0){
            //erreur
            io.to(socket.id).emit('warning',"Aucune partie trouvée...");
        }
    });

})
function getRandomPass(){
    var pass = (new Date()).getTime();
    for(var i = 0; i < tab_room.length;i++){
        if(tab_room[i].id === pass){
            i = 0;
            pass = (new Date()).getTime();
        }
    }
    return pass+"";
}
