package com.example.porjetmobile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.WindowManager;

import java.util.ArrayList;

import model.obstacle.Obstacle;
import socket.SocketConnection;

public class waiting_connection extends AppCompatActivity {
    private SocketConnection sc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_waiting_connection);
        //on met en fullscren et on vire la barre moche du haut
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);

        sc = SocketConnection.getInstance(this,null);
        sc.initConnection();
        sc.readId();
    }
}