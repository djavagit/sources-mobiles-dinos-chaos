package com.example.porjetmobile;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import socket.SocketConnection;

public class findGameActivity extends AppCompatActivity {

    private ImageButton r;
    private SocketConnection sc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_game);

        //on met en fullscren et on vire la barre moche du haut
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);


        sc = SocketConnection.getInstance(this,null);

        sc.send("find_game","");

        r = findViewById(R.id.imageButton_join_return);

        r.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });
    }
    @Override
    protected void onStop() {
        super.onStop();
        sc.send("deleteGame","");
    }
}