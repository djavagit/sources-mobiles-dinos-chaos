package com.example.porjetmobile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import socket.SocketConnection;

public class joinActivity extends AppCompatActivity {

    private ImageButton r;
    private SocketConnection sc;
    private Button valid;
    private EditText e;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join);

        //on met en fullscren et on vire la barre moche du haut
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        sc = SocketConnection.getInstance(this,null);

        r = findViewById(R.id.imageButton_join_return);

        r.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });

        valid = findViewById(R.id.button_validate_join);
        e = findViewById(R.id.editText_join_password);

        valid.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                    String pass = String.valueOf(e.getText());
                    if(pass.length() > 0 && !pass.equals(getResources().getString(R.string.noID))){
                        sc.send("join_game" ,pass);
                    }else{
                        Toast.makeText(getApplicationContext(),R.string.mauvais_mdp,Toast.LENGTH_LONG).show();
                    }
                }
        });

    }

}