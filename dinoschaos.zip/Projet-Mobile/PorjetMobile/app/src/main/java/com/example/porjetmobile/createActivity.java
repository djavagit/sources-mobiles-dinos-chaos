package com.example.porjetmobile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import io.socket.emitter.Emitter;
import socket.SocketConnection;

public class createActivity extends AppCompatActivity {

    private ImageButton r;

    private SocketConnection sc;
    private Button valid;
    private EditText e;
    private boolean searching;

    public void setSearching(boolean searching) {
        this.searching = searching;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);
        searching = false;

        //on met en fullscren et on vire la barre moche du haut
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);

        sc = SocketConnection.getInstance(this,null);

        r = findViewById(R.id.imageButton_create_return);

        r.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });


        valid = findViewById(R.id.button_validate_create);
        e = findViewById(R.id.editText_create_password);

        valid.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                if (searching){
                    //on annule la recherche
                    e.setFocusableInTouchMode(true);
                    e.setBackgroundColor(getResources().getColor(R.color.transparent_full));
                    valid.setText(R.string.validate);
                    setSearching(false);
                } else {
                    //on lance la recherche
                    String pass = String.valueOf(e.getText());
                    if(pass.length() > 0 && !pass.equals(getResources().getString(R.string.noID))){
                        e.setFocusable(false);
                        e.setBackgroundColor(getResources().getColor(R.color.transparent));
                        valid.setText(R.string.cancel);
                        setSearching(true);
                        sc.send("new_game" ,pass);
                    }else{
                        Toast.makeText(getApplicationContext(),R.string.mauvais_mdp,Toast.LENGTH_LONG).show();
                    }
                }
            }
        });
    }
    @Override
    public void onRestart() {
        super.onRestart();
        e.setFocusableInTouchMode(true);
        e.setBackgroundColor(getResources().getColor(R.color.transparent_full));
        e.setText("");
        valid.setText(R.string.validate);
        setSearching(false);
    }
}