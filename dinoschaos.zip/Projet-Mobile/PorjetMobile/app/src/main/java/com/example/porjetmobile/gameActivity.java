package com.example.porjetmobile;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.net.URISyntaxException;
import java.util.ArrayList;

import fragments.GameFragment;
import fragments.PauseFragment;
import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;
import model.Player;
import model.World;
import model.obstacle.Cactus;
import model.obstacle.Eagle;
import model.obstacle.Obstacle;
import model.obstacle.Rock;
import model.obstacle.Star;
import socket.SocketConnection;
import view.CanvasView;

public class gameActivity extends AppCompatActivity {

    private SocketConnection sc;
    private CanvasView cv;
    ExtendedFloatingActionButton cactusButton,rockButton,eagleButton,blindButton,boltButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        //on met en fullscren et on vire la barre moche du haut
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);

        Intent intent = this.getIntent();
        int score = intent.getIntExtra("score",-1);
        int life = intent.getIntExtra("life",-1);
        String obs = intent.getStringExtra("obst");
        Bundle bundle = intent.getExtras();
        ArrayList<Obstacle> o = (ArrayList<Obstacle>) bundle.getSerializable("obstacle");

        cv = findViewById(R.id.canvasView);

        sc = SocketConnection.getInstance(this,cv);

        cactusButton = findViewById(R.id.floatingActionButton_cactus1);
        rockButton = findViewById(R.id.floatingActionButton_rock);
        eagleButton = findViewById(R.id.floatingActionButton_eagle);
        boltButton = findViewById(R.id.floatingActionButton_bolt);
        blindButton = findViewById(R.id.floatingActionButton_blind);

        if (cv.getPlayer().isDino()){
            cactusButton.setVisibility(View.GONE);
            rockButton.setVisibility(View.GONE);
            eagleButton.setVisibility(View.GONE);
            boltButton.setVisibility(View.GONE);
            blindButton.setVisibility(View.GONE);
        } else {
            cactusButton.setText(String.valueOf(Obstacle.tab_price[0]));
            rockButton.setText(String.valueOf(Obstacle.tab_price[1]));
            eagleButton.setText(String.valueOf(Obstacle.tab_price[2]));
            blindButton.setText(String.valueOf(Player.power_price[0]));
            boltButton.setText(String.valueOf(Player.power_price[1]));
        }

        if(score != -1) {
            cv.getWorld().setCurrentScore(score);
        }
        if(life != -1) {
            cv.getWorld().setLife(life);
        }
        if(o != null) {
            cv.getWorld().setObstacles(o);
        }
        if(obs != null && !obs.equals("")){
            String obst[] = obs.split("/");
            for (int i = 0; i < obst.length;i++){
                String obsta[] = obst[i].split("#");
                if(obsta[0].equals("rock")){
                    cv.getWorld().addObstacle(new Rock(Float.parseFloat(obsta[1]),Float.parseFloat(obsta[2]),cv.getWorld().getSize()));
                }else if(obsta[0].equals("eagle")){
                    cv.getWorld().addObstacle(new Eagle(Float.parseFloat(obsta[1]),Float.parseFloat(obsta[2]),cv.getWorld().getSize()));
                }else if(obsta[0].equals("star")){
                    cv.getWorld().addObstacle(new Star(Float.parseFloat(obsta[1]),Float.parseFloat(obsta[2]),cv.getWorld().getSize()));
                }else{
                    cv.getWorld().addObstacle(new Cactus(Float.parseFloat(obsta[1]),Float.parseFloat(obsta[2]),cv.getWorld().getSize()));
                }
            }
        }

        cv.setEndGameListener(new CanvasView.GameListener() {
            @Override
            public void gameEnded(boolean win) {
                cv.pause_game();
                FragmentManager fm = getSupportFragmentManager();
                GameFragment e = GameFragment.newInstance(win);
                e.setCancelable(false);
                e.show(fm, "fragment_end_game");
            }

            @Override
            public void gameDeconnection() {
                cv.pause_game();
                FragmentManager fm = getSupportFragmentManager();
                PauseFragment e = PauseFragment.newInstance();
                e.setCancelable(false);
                e.show(fm, "fragment_pause_game");
            }

            @Override
            public void resetColorButton() {
                cactusButton.setBackgroundTintList(getResources().getColorStateList(R.color.transparent_full));
                rockButton.setBackgroundTintList(getResources().getColorStateList(R.color.transparent_full));
            }

            @Override
            public void resetColorFlyingButton() {
                eagleButton.setBackgroundTintList(getResources().getColorStateList(R.color.transparent_full));
            }

            @Override
            public void resetColorPowerButton() {
                blindButton.setBackgroundTintList(getResources().getColorStateList(R.color.transparent_full));
                boltButton.setBackgroundTintList(getResources().getColorStateList(R.color.transparent_full));
            }

            @Override
            public void changeColorPowerButton() {
                boltButton.setBackgroundTintList(getResources().getColorStateList(R.color.gray));
                blindButton.setBackgroundTintList(getResources().getColorStateList(R.color.gray));
            }

        });
        cactusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(cv.getPlayer().getCurrent_cd_obstacle() >= cv.getPlayer().getCd_obstacle() &&
                        cv.getPlayer().getMoney() - Obstacle.tab_price[0] >= 0){
                    sc.send("new_obstacles",sc.getId(),"Cactus");
                    cv.getPlayer().setCurrent_cd_obstacle(0);
                    cactusButton.setBackgroundTintList(getResources().getColorStateList(R.color.gray));
                    rockButton.setBackgroundTintList(getResources().getColorStateList(R.color.gray));
                }
            }
        });

        rockButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(cv.getPlayer().getCurrent_cd_obstacle() >= cv.getPlayer().getCd_obstacle() &&
                        cv.getPlayer().getMoney() - Obstacle.tab_price[1] >= 0){
                    sc.send("new_obstacles",sc.getId(),"Rock");
                    cv.getPlayer().setCurrent_cd_obstacle(0);
                    rockButton.setBackgroundTintList(getResources().getColorStateList(R.color.gray));
                    cactusButton.setBackgroundTintList(getResources().getColorStateList(R.color.gray));
                }
            }
        });

        boltButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(cv.getPlayer().isPowerAvailable() && cv.getPlayer().getMoney() - Player.power_price[1] >= 0){
                    sc.send("power",sc.getId(),"bolt");
                }
            }
        });

        blindButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(cv.getPlayer().isPowerAvailable() && cv.getPlayer().getMoney() - Player.power_price[0] >= 0){
                    sc.send("power",sc.getId(),"blind");
                }
            }
        });

        eagleButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(cv.getPlayer().getCurrent_cd_flying_obstacle() >= cv.getPlayer().getCd_obstacle() &&
                        cv.getPlayer().getMoney() - Obstacle.tab_price[2] >= 0){
                    sc.send("new_obstacles",sc.getId(),"Eagle-"+Math.random());
                    cv.getPlayer().setCurrent_cd_flying_obstacle(0);
                    eagleButton.setBackgroundTintList(getResources().getColorStateList(R.color.gray));
                }
            }
        });
    }
    public static Bitmap scaleDown(Bitmap realImage, float maxImageSize,
                                   boolean filter) {
        float ratio = Math.min(
                maxImageSize / realImage.getWidth(),
                maxImageSize / realImage.getHeight());
        int width = Math.round(ratio * realImage.getWidth());
        int height = Math.round(ratio * realImage.getHeight());

        Bitmap newBitmap = Bitmap.createScaledBitmap(realImage, width,
                height, filter);
        return newBitmap;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        cv.releaseMedias();
    }
}