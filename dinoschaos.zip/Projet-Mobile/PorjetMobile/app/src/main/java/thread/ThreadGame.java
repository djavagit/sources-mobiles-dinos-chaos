package thread;

import java.util.Observable;

public class ThreadGame extends Observable implements Runnable{
    //stop the thread
    private boolean end;
    //time of pause
    public  int ms;

    public ThreadGame(int ms){
        this.ms = ms;
    }

    public void startThread(){
        end = true;
        Thread t = new Thread(this);
        t.start();
    }

    public void stopThread(){
        end = false;
    }

    @Override
    public void run() {
        while(end){

            setChanged();
            notifyObservers();

            try{
                Thread.sleep(ms);
            }catch(Exception e){
                e.printStackTrace();
            }
        }
    }
}
