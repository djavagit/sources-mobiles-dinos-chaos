package model;

import android.graphics.Bitmap;

import java.io.Serializable;
import java.util.ArrayList;

import model.obstacle.Obstacle;

public class World implements Serializable {

    private final int  scoreMAX = 1500;
    private int size_char;
    private float gravity,maxY,bg_pos,speed_bg,ground_pos;
    private float currentScore;
    private Character c;
    private ArrayList<Obstacle> obstacles;

    private static Bitmap ground,bg;

    public World(int size,int size_obst){
        bg_pos = 0;
        ground_pos = 0;
        speed_bg = 5;
        size_char = size_obst;
        currentScore = (float) (scoreMAX * 0.03);
        gravity = (float) 0.1 * size_obst;
        c = new Character(size);
        obstacles = new ArrayList<Obstacle>();
    }


    //GETTERS AND SETTERS
    public int getSize(){return size_char;}
    public float getBg_pos(){return bg_pos;}
    public float getGround_pos(){return ground_pos;}
    public void move_bg(int max){
        bg_pos -= speed_bg;
        if(bg_pos <= -max){
            bg_pos = 0;
        }
        ground_pos -= Obstacle.speed;
        if(ground_pos <= -max){
            ground_pos = 0;
        }
    }
    public  Bitmap getBG(){return bg;}
    public  Bitmap getGround(){return ground;}
    public static void setGround(Bitmap b){ground = b;}
    public static void setBg(Bitmap b){bg = b;}
    public float getGravity() {
        return gravity;
    }

    public float getMaxY() {
        return maxY;
    }

    public void setMaxY(float maxY) {
        this.maxY = maxY;
    }

    public int getScoreMAX() {
        return scoreMAX;
    }

    public float getCurrentScore() {
        return currentScore;
    }

    public void setCurrentScore(float currentScore) {
        this.currentScore = currentScore;
    }

    public Character getC() {
        return c;
    }

    public void setLife(int life){c.setLifeReco(life);}

    public Obstacle getObstacles(int i) {
        return obstacles.get(i);
    }

    public ArrayList<Obstacle> getObstacles() {
        return obstacles;
    }

    public void setObstacles(ArrayList<Obstacle> l){obstacles = l;}

    public void addObstacle(Obstacle o){
        obstacles.add(o);
    }
    public int lengthObstacle(){
        return obstacles.size();
    }
    public void removeObstacle(int i){
        obstacles.remove(i);
    }

}
