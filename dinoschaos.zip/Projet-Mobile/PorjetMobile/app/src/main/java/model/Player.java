package model;

public class Player {

    private String role;
    private int money,cd_obstacle, current_cd_obstacle, current_cd_flying_obstacle,power_current_cd,invicible,cd_invicible, current_blind;
    public static int power_price[] = {100,250};
    public final static int power_duration = 7000;

    private static Player instance;

    static {
        instance = new Player();
    }

    public static Player getInstance() {
        return instance;
    }

    private Player(){
    }

    public void initPlayer(String role){
        this.role = role;
        money = 0;
        power_current_cd = power_duration;
        cd_obstacle = 1000;
        current_cd_obstacle = cd_obstacle;
        invicible = 0;
        cd_invicible = 5000;
        current_blind = 0;
        current_cd_flying_obstacle = cd_obstacle;

    }
    public void initPlayer(String role,int money){
        this.role = role;
        this.money = money;
        cd_obstacle = 1000;
        power_current_cd = power_duration;
        current_cd_obstacle = cd_obstacle;
        invicible = 0;
        cd_invicible = 100;
        current_blind = 0;
        current_cd_flying_obstacle = cd_obstacle;
    }

    public boolean isDino(){return role.equals("Dino");}
    public boolean isPowerAvailable(){return power_current_cd >= power_duration;}

    public int getCurrent_cd_flying_obstacle() {
        return current_cd_flying_obstacle;
    }
    public void setCurrent_cd_obstacle(int current_cd_obstacle) {
        this.current_cd_obstacle = current_cd_obstacle;
    }
    public void setCurrent_cd_flying_obstacle(int current_cd_obstacle) {
        this.current_cd_flying_obstacle = current_cd_obstacle;
    }
    public int getCurrent_cd_obstacle() {
        return current_cd_obstacle;
    }
    public void addCurrent_cd_obstacle(int amount) {
        this.current_cd_obstacle += amount;
        this.current_cd_flying_obstacle += amount;
        this.power_current_cd += amount;
    }

    public int getCd_obstacle() {
        return cd_obstacle;
    }

    public int getMoney() {
        return money;
    }
    public void incrMoney(int amount) {
        this.money += amount;
    }
    public int getInvicible() {
        return invicible;
    }
    public void setInvicible(int invicible) {
        this.invicible = invicible;
    }
    public void addInvicible(int delta){
        this.invicible += delta;
    }
    public int getCd_invicible() {
        return cd_invicible;
    }
    public void setCurrent_cd_power_bolt() {
        power_current_cd = 0;
    }
    public int getCurrent_blind() {
        return current_blind;
    }
    public void setCurrent_blind(int current_blind) {
        this.current_blind = current_blind;
    }
    public void addCurren_blind(int delta){
        this.current_blind += delta;
    }
}
