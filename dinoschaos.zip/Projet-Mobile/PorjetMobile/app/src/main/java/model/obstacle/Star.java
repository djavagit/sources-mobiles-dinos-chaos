package model.obstacle;

import android.graphics.Bitmap;

import com.example.porjetmobile.R;

public class Star extends Obstacle{
    public static Bitmap[] starBms = new Bitmap[16];
    private static Bitmap bm;
    private int currentStar;
    public static final int star_id[] = {R.drawable.star1, R.drawable.star2, R.drawable.star3, R.drawable.star4,
            R.drawable.star5, R.drawable.star6, R.drawable.star7, R.drawable.star8,
            R.drawable.star9, R.drawable.star10, R.drawable.star11, R.drawable.star12,
            R.drawable.star13, R.drawable.star14, R.drawable.star15, R.drawable.star16 };

    public Star(float x, float y,int size) {
        super(x - 200, y, size);
        currentStar = 0;
    }

    public static void setBitmap(Bitmap btm){
        bm = btm;
    }

    public void nextImage() {
        currentStar++;
        if (currentStar >= starBms.length) {
            currentStar = 0;
        }
    }

    @Override
    public Bitmap getBitmap() {
        return starBms[currentStar];
    }
}
