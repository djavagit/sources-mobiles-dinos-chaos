package model.obstacle;

import android.graphics.Bitmap;
import com.example.porjetmobile.R;

public class Eagle extends Obstacle {
    public static Bitmap[] fly = new Bitmap[4];
    private int currentfly;
    public static final int fly_id[] = {R.drawable.eagle_1, R.drawable.eagle_2, R.drawable.eagle_3, R.drawable.eagle_4};


    public Eagle(float x, float y,int size) {
        super(x - 200, y, size);
        currentfly = 0;
    }

    public void nextImage() {
        currentfly++;
        if (currentfly >= fly.length) {
            currentfly = 0;
        }
    }

    @Override
    public Bitmap getBitmap() {
        return fly[currentfly];
    }

}

