package model.obstacle;


import android.graphics.Bitmap;

public class Rock extends Obstacle{

    private static Bitmap bm;

    public Rock(float x,float y,int size) {
        super(x, y, size);
    }

    public static void setBitmap(Bitmap btm){
        bm = btm;
    }

    @Override
    public Bitmap getBitmap() {
        return bm;
    }

}
