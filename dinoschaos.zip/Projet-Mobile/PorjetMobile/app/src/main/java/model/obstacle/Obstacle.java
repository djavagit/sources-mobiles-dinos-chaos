package model.obstacle;

import android.graphics.Bitmap;

public abstract class Obstacle {

    private boolean haveTouchPlayer;
    private float x,y,width;
    public static float speed=10;
    private static float defaultSpeed;
    public static final int tab_price[] = {50, 50, 75};

    public Obstacle(float x, float y, float width){
        this.x = x;
        this.y = y;
        this.width = width;
        haveTouchPlayer = false;
    }

    public static void setSpeed(int screenWidth){
        speed = (float) (0.01 * screenWidth);
        defaultSpeed = speed;
    }

    public static void resetSpeed() {
        speed = defaultSpeed;
    }

    public static void increaseSpeed() {
        speed *= 1.5;
    }

    public boolean moveObstacle(){
        x -= speed;
        if( x < -width){
            return true;
        }
        return false;
    }

    public boolean isTouchedPlayer(){
        return haveTouchPlayer;
    }

    public void touchedPlayer(){
        haveTouchPlayer = true;
    }

    //GETTERS AND SETTERS
    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

    public float getWidth() {
        return width;
    }

    public abstract Bitmap getBitmap();


    public String getType() {
        if(this instanceof Eagle){
            return "eagle";
        }else if(this instanceof Cactus){
            return "cactus";
        } else if(this instanceof Star){
            return "star";
        }
        return "rock";
    }
}
