package model;

import android.graphics.Bitmap;

import com.example.porjetmobile.R;

import java.io.Serializable;

public class Character implements Serializable {

    private final float x = 10;
    private float y,width,height,jump_force;
    private int currentCdJump,cd_jump,life;
    private boolean double_jump;

    //images
    private int currentRun,currentDead;
    public Bitmap[] run;
    public Bitmap[] jump;
    public Bitmap[] dead;
    public Bitmap heart;
    public final int run_id[] = {R.drawable.run_1,R.drawable.run_2,R.drawable.run_3,R.drawable.run_4,R.drawable.run_5,R.drawable.run_6,R.drawable.run_7,R.drawable.run_8};
    public final int jump_id[] = {R.drawable.jump_1,R.drawable.jump_2,R.drawable.jump_3,R.drawable.jump_4,R.drawable.jump_5,R.drawable.jump_6,R.drawable.jump_7,R.drawable.jump_8,R.drawable.jump_9,R.drawable.jump_10,R.drawable.jump_11,R.drawable.jump_12};
    public final int dead_id[] = {R.drawable.dead_1, R.drawable.dead_2, R.drawable.dead_3,R.drawable.dead_4,R.drawable.dead_5,R.drawable.dead_6,R.drawable.dead_7,R.drawable.dead_8};

    public Character(int size) {
        this.y = 0;
        this.width = size;
        life = 3;
        this.height = size;
        cd_jump = 900;
        jump_force=0;
        currentCdJump=cd_jump;
        double_jump = false;
        currentRun = 0;
        currentDead = 0;
        run = new Bitmap[8];
        jump = new Bitmap[12];
        dead = new Bitmap[8];
    }

    public Bitmap getHeartBm(){
        return heart;
    }
    public void setHeart(Bitmap b){
        heart = b;
    }

    public Bitmap getImage(){
        if(life > 0) {
            if (isJumping()) {
                return jump[currentRun];
            } else {
                if (currentRun >= run.length ) {
                    currentRun = 0;
                }
                return run[currentRun];
            }
        }else{
            return dead[currentDead];
        }
    }
    public void nextImage(){
        if(life > 0) {
            currentRun++;
            if (currentRun >= run.length && !isJumping() || currentRun >= jump.length && isJumping()) {
                currentRun = 0;
            }
        }else{
            currentDead++;
            if(currentDead >= dead.length){
                currentDead = 0;
            }
        }
    }

    public boolean endAnim(){return currentDead == dead.length-1;}
    public void resetCurrentRun(){
        currentRun = 0;
    }
    public boolean isJumping(){
        return currentCdJump < cd_jump;
    }


    //GETTERS AND SETTERS
    public boolean getDoubleJump(){return double_jump;}
    public void setDoubleJump(boolean b){double_jump = b;}
    public float getHeight() {
        return height;
    }

    public int getCurrentCdJump() {
        return currentCdJump;
    }


    public void setJump_force(float jump_force) {
        this.jump_force = jump_force;
    }

    public void setCurrentCdJump(int currentCdJump) {
        this.currentCdJump = currentCdJump;
    }
    public void addCurrentCdJump(int currentCdJump) {
        this.currentCdJump += currentCdJump;
    }
    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

    public void setY(float y) {
        this.y = y;
    }
    public void gravity(float g,float max){
        this.y += g;
        if(y >= max){
            y = max;
        }
    }
    public void jump(){
        this.y -= jump_force;
    }
    public float getWidth() {
        return width;
    }

    public int getCd_jump() {
        return cd_jump;
    }

    public int getLife(){return life;}
    public void setLife(){life -= 1;}

    public void setLifeReco(int life) {
        this.life = life;
    }
}
