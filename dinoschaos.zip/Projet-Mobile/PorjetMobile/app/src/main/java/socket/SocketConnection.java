package socket;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.DisplayMetrics;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;

import com.example.porjetmobile.MainActivity;
import com.example.porjetmobile.R;
import com.example.porjetmobile.createActivity;
import com.example.porjetmobile.gameActivity;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.net.URISyntaxException;
import java.util.ArrayList;

import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;
import model.Character;
import model.Player;
import model.World;
import model.obstacle.Eagle;
import model.obstacle.Obstacle;
import view.CanvasView;

public class SocketConnection {

    private static Activity a;
    private static CanvasView cv;
    private final String SERVER_PATH = "http://dino-chaos.herokuapp.com/";
    private Socket s;
    private String id_room;
    private static final String file = "SHARED_PREF_FILE";
    private static SocketConnection instance;

    static {
        instance = new SocketConnection();
    }

    public static SocketConnection getInstance(Activity b,CanvasView c) {
        a = b;
        cv = c;
        return instance;
    }
    public static SocketConnection getInstance() {
        return instance;
    }
    private SocketConnection(){}

    public void initConnection(){
        try {
            s = IO.socket(SERVER_PATH);
        } catch (URISyntaxException e) {}

        s.on("con", new Emitter.Listener() {
            @Override
            public void call(final Object... args) {
                if (a != null) {
                    Intent intent = new Intent(a.getApplicationContext(), MainActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    a.getApplicationContext().startActivity(intent);
                }
            }
        });

        s.on("warning", new Emitter.Listener() {
            @Override
            public void call(final Object... args) {
                if (a != null) {
                    a.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            String msg = (String) args[0];
                            if(msg.equals("Une partie avec cette identifiant existe déjà")){
                                ((EditText)a.findViewById(R.id.editText_create_password)).setFocusableInTouchMode(true);
                                ((EditText)a.findViewById(R.id.editText_create_password)).setBackgroundColor(a.getResources().getColor(R.color.transparent_full));
                                ((Button)a.findViewById(R.id.button_validate_create)).setText(R.string.validate);
                                ((createActivity)a).setSearching(false);
                            }
                            Toast.makeText(a.getApplicationContext(), msg, Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
        });
        s.on("start_game", new Emitter.Listener() {
            @Override
            public void call(final Object... args) {
                if (a != null) {
                    id_room = String.valueOf(args[0]);
                    a.getSharedPreferences(file, Context.MODE_PRIVATE)
                            .edit()
                            .putString(a.getResources().getString(R.string.ID_ROOM), id_room)
                            .apply();


                    Player.getInstance().initPlayer((String) args[1]);
                    Intent intent = new Intent(a.getApplicationContext(), gameActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent.putExtra("World", (World) null);
                    a.getApplicationContext().startActivity(intent);
                }
            }
        });
        s.on("ready", new Emitter.Listener() {
            @Override
            public void call(final Object... args) {
                if (cv != null) {
                    cv.start_game();
                    if(a != null) {
                        Fragment prev = ((FragmentActivity) a).getSupportFragmentManager().findFragmentByTag("fragment_pause_game");
                        if (prev != null) {
                            DialogFragment df = (DialogFragment) prev;
                            df.dismiss();
                        }
                    }
                }
            }
        });
        s.on("life_lost", new Emitter.Listener() {
            @Override
            public void call(final Object... args) {
                if (cv != null) {
                    cv.life_lost();
                }
            }
        });
        s.on("jump", new Emitter.Listener() {
            @Override
            public void call(final Object... args) {
                if (cv != null) {
                  cv.jump();
                }
            }
        });
        s.on("new_obstacles", new Emitter.Listener() {
            @Override
            public void call(final Object... args) {
                if (cv != null) {
                    cv.addObstacle((String) args[0]);
                }
            }
        });
        s.on("power", new Emitter.Listener() {
            @Override
            public void call(final Object... args) {
                if (cv != null) {
                    String power = (String) args[0];
                    cv.addPower(power);
                }
            }
        });

        s.on("disconnection", new Emitter.Listener() {
            @Override
            public void call(final Object... args) {
                if (cv != null) {
                    cv.deconnection();
                }
            }
        });

        s.on("reco", new Emitter.Listener() {
            @Override
            public void call(final Object... args) {
               a.runOnUiThread(new Runnable() {
                   @Override
                   public void run() {

                       Toast.makeText(a,"Votre adversaire se reconnecte",Toast.LENGTH_LONG).show();
                   }
               });
                String role = "Builder";
                if(!cv.getPlayer().isDino()){
                    role = "Dino";
                }
                String obstacles = "";
                ArrayList<Obstacle> obs = cv.getWorld().getObstacles();
                if(obs.size() > 0){
                    obstacles += obs.get(0).getType() + "#" + obs.get(0).getX() + "#" + obs.get(0).getY();
                    for (int i = 1;i < obs.size() ; i++ ){
                        obstacles += "/"+ obs.get(i).getType() + "#" + obs.get(i).getX() + "#" + obs.get(i).getY();
                    }
                }
                s.emit("reconnect_data",id_room,(int)cv.getWorld().getCurrentScore(),role,cv.getPlayer().getMoney(),cv.getWorld().getC().getLife(),obstacles);
                send("ready",getId());
            }
        });

        s.on("reconnect_data", new Emitter.Listener() {
            @Override
            public void call(final Object... args) {
                id_room = (String) args[0];

                Player p = Player.getInstance();
                p.initPlayer((String) args[2],(int) args[3]);

                Intent intent = new Intent(a.getApplicationContext(), gameActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra("score",(int)args[1]);
                intent.putExtra("life",(int)args[4]);
                intent.putExtra("obst",(String)args[5]);
                a.getApplicationContext().startActivity(intent);
            }
        });

        s.connect();
    }

    public void send(String event,String content){
        s.emit(event,content);
    }
    public void send(String event,String id,String content){
        s.emit(event,id,content);
    }

    public void readId(){
        String id = a.getSharedPreferences(file, Context.MODE_PRIVATE).getString(a.getResources().getString(R.string.ID_ROOM), a.getResources().getString(R.string.noID));
        if(!id.equals(a.getResources().getString(R.string.noID))){
            send("reco",id);
        }
    }

    public void deleteId(){
        a.getSharedPreferences(file, Context.MODE_PRIVATE).edit().remove(a.getResources().getString(R.string.ID_ROOM)).apply();
    }

    public String getId(){return id_room;}
}
