package fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import com.example.porjetmobile.MainActivity;
import com.example.porjetmobile.R;

public class GameFragment extends DialogFragment {
    private TextView text;
    private Button leave;

    public GameFragment() {}

    public static GameFragment newInstance(boolean win) {
        GameFragment frag = new GameFragment();
        Bundle args = new Bundle();
        args.putBoolean("message", win);
        frag.setArguments(args);
        return frag;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        // Get field from view
        leave = (Button) view.findViewById(R.id.end_game_button);
        leave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getActivity(), MainActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(i);
            }
        });
        text = (TextView) view.findViewById(R.id.text_end);
        String msg = "Vous avez perdu :(";
        if(getArguments().getBoolean("message")){
            msg = "Vous avez gagnez !";
        }
        text.setText(msg);
        getDialog().getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.end_game_fragment, container);
    }


}
