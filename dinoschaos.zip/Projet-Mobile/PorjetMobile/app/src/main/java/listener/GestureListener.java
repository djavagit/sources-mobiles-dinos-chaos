package listener;

import android.view.GestureDetector;
import android.view.MotionEvent;


import model.Player;
import socket.SocketConnection;

public class GestureListener implements GestureDetector.OnGestureListener,GestureDetector.OnDoubleTapListener {

    private SocketConnection sc;
    private Player p;
    public GestureListener(SocketConnection sc) {
      this.sc = sc;
      p = Player.getInstance();
    }

    @Override
    public boolean onDown(MotionEvent event) {
        return true;
    }

    @Override
    public void onShowPress(MotionEvent motionEvent) {


    }

    @Override
    public boolean onSingleTapUp(MotionEvent motionEvent) {
        if(p.isDino()) {
            sc.send("jump", sc.getId());
        }
        return false;
    }

    @Override
    public boolean onSingleTapConfirmed(MotionEvent e) {
        return true;
    }

    @Override
    public void onLongPress(MotionEvent e) {
    }

    @Override
    public boolean onDoubleTap(MotionEvent e) {
        return true;
    }

    @Override
    public boolean onDoubleTapEvent(MotionEvent motionEvent) {
        return false;
    }

    @Override
    public boolean onScroll(MotionEvent e1, MotionEvent e2,
                            float distanceX, float distanceY) {
        return true;
    }

    @Override
    public boolean onFling(MotionEvent event1, MotionEvent event2,
                           float velocityX, float velocityY) {
        return true;
    }
}
