package view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.media.MediaActionSound;
import android.media.MediaPlayer;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewPropertyAnimator;

import androidx.annotation.Nullable;


import com.example.porjetmobile.R;
import com.example.porjetmobile.gameActivity;

import java.io.Serializable;
import java.util.Observable;
import java.util.Observer;
import java.util.Random;

import listener.GestureListener;
import model.Character;
import model.Player;
import model.World;
import model.obstacle.Cactus;
import model.obstacle.Eagle;
import model.obstacle.Obstacle;
import model.obstacle.Rock;
import model.obstacle.Star;
import socket.SocketConnection;
import thread.ThreadGame;

public class CanvasView  extends View implements Observer, Serializable {

    private World w;
    private final int cd_thread = 17;
    private Player player;
    private SocketConnection sc;
    private Paint p;
    private int width,height;
    private ThreadGame ta;
    private ThreadGame tg;
    private GestureDetector gd;
    private static Bitmap coinImage;
    private static Bitmap inkImage;
    private Star star;
    private MediaPlayer jumpMedia,starMedia,ouchMedia,deathMedia,boltMedia,inkMedia;

    public CanvasView(Context context) {
        super(context);
        init(null);
    }

    public CanvasView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(attrs);
    }

    public CanvasView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(attrs);
    }


    //partie du listener
    private GameListener listener;

    //interface
    public interface GameListener {
        void gameEnded(boolean win);
        void gameDeconnection();
        void resetColorButton();
        void resetColorFlyingButton();
        void resetColorPowerButton();
        void changeColorPowerButton();
    }
    public void setEndGameListener(GameListener listener) {
        this.listener = listener;
    }


    private void init(@Nullable AttributeSet set){
        player = Player.getInstance();
        sc = SocketConnection.getInstance();


        //sound
        jumpMedia = MediaPlayer.create(getContext(), R.raw.jump);
        starMedia = MediaPlayer.create(getContext(), R.raw.star_pickup);
        ouchMedia = MediaPlayer.create(getContext(), R.raw.ouch);
        deathMedia = MediaPlayer.create(getContext(), R.raw.dinosaur_death);
        boltMedia = MediaPlayer.create(getContext(), R.raw.thunder);
        inkMedia = MediaPlayer.create(getContext(), R.raw.splash_ink);

        //define paint
        p = new Paint();
        p.setAntiAlias(true);
        p.setFilterBitmap(true);
        p.setDither(true);
        p.setColor(Color.YELLOW);
        p.setStyle(Paint.Style.FILL);
        p.setTextSize(100);

        //get screen size
        DisplayMetrics dm = getContext().getResources().getDisplayMetrics();
        width = (int) (dm.widthPixels * 1.1);
        height = dm.heightPixels;

        int size = (int)(0.28 * height);
        w = new World(size,(int)(0.19 * height));
        Character c = w.getC();
        c.setY((int)(0.77 * height));
        w.setMaxY((int)(0.77 * height));
        Obstacle.setSpeed(width);

        //star
        star = new Star(610 + getWidth()/3, 0,(int)(0.13 * height));

        //loading bitmap images
        for(int i = 0;i < c.run.length;i++){
            c.run[i] = gameActivity.scaleDown( BitmapFactory.decodeResource(getContext().getResources(),
                    c.run_id[i]),c.getWidth() , true);
        }
        for(int i = 0;i < c.jump.length;i++){
            c.jump[i] = gameActivity.scaleDown( BitmapFactory.decodeResource(getContext().getResources(),
                    c.jump_id[i]),c.getWidth() , true);
        }
        for(int i = 0;i < c.dead.length;i++){
            c.dead[i] = gameActivity.scaleDown( BitmapFactory.decodeResource(getContext().getResources(),
                    c.dead_id[i]),c.getWidth() , true);
        }
        for(int i = 0; i < Eagle.fly.length; i++){
            Eagle.fly[i] = gameActivity.scaleDown( BitmapFactory.decodeResource(getContext().getResources(),
                    Eagle.fly_id[i]),w.getSize(), true);
        }

        for(int i = 0; i < Star.starBms.length; i++){
            Star.starBms[i] = gameActivity.scaleDown( BitmapFactory.decodeResource(getContext().getResources(),
                    Star.star_id[i]),star.getWidth() , true);
        }
        World.setGround(gameActivity.scaleDown( BitmapFactory.decodeResource(getContext().getResources(),
                R.drawable.bg_ground),width , true));
        World.setBg(gameActivity.scaleDown( BitmapFactory.decodeResource(getContext().getResources(),
                R.drawable.bg_game),width , true));
        w.setBg(Bitmap.createScaledBitmap(w.getBG(), width, height, false));
        Rock.setBitmap(gameActivity.scaleDown( BitmapFactory.decodeResource(getContext().getResources(),
                R.drawable.rock),w.getSize() , true));
        Cactus.setBitmap(gameActivity.scaleDown( BitmapFactory.decodeResource(getContext().getResources(),
                R.drawable.cactus1_00),w.getSize() , true));
        c.setHeart(gameActivity.scaleDown( BitmapFactory.decodeResource(getContext().getResources(),
                R.drawable.heart),w.getSize()/2 , true));
        coinImage = gameActivity.scaleDown(BitmapFactory.decodeResource(getContext().getResources(),
                R.drawable.coin), (int)(0.4 * w.getSize()), true);
        inkImage = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(getContext().getResources(), R.drawable.ink), width, height, false);

        //creating gesture detector
        gd = new GestureDetector(getContext(),
                 new GestureListener(SocketConnection.getInstance(null,this)));


        //starting thread
        ta = new ThreadGame(75);
        ta.addObserver(this);

        tg = new ThreadGame(cd_thread);
        tg.addObserver(this);

        sc.send("ready",sc.getId());
    }

    public void start_game(){
        tg.startThread();
        ta.startThread();
    }

    public void pause_game(){
        tg.stopThread();
        ta.stopThread();
    }

    public void deconnection(){
        listener.gameDeconnection();
    }

    public void life_lost(){
        w.getC().setLife();
    }

    public Player getPlayer() {
        return player;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        //bg
        int h = (int)(0.90 * height);
        draw_entity(canvas,w.getBG(),w.getBg_pos(),0);
        draw_entity(canvas,w.getBG(),w.getBg_pos() + width,0);
        draw_entity(canvas,w.getGround(),w.getGround_pos(),h);
        draw_entity(canvas,w.getGround(),w.getGround_pos()+ width,h);

        //drawing obstacles
        for (int i = 0; i < w.lengthObstacle();i++){
            Obstacle o = w.getObstacles(i);
            draw_entity(canvas,o.getBitmap(),o.getX(),o.getY());
        }

        //drawing invicible
        if (player.getInvicible()>0){
            draw_entity(canvas,
                    star.getBitmap(),
                    600 + canvas.getWidth()/3 + 20,
                    10);
        }

        //drawing character
        draw_entity(canvas, w.getC().getImage(), w.getC().getX(), w.getC().getY());

        //drawing ink
        if (player.getCurrent_blind() > 0){
            draw_entity(canvas, inkImage, width/10, height/10);
        }

        //draw earth
        for (int i = 0; i < w.getC().getLife() ; i++){
            draw_entity(canvas, w.getC().getHeartBm(), (w.getSize()/2) * i, 0);
        }

        //Draw money text
        if(!player.isDino()){
            draw_entity(canvas, coinImage, 0, 150);
            p.setColor(getResources().getColor(R.color.money));
            canvas.drawText(String.valueOf(player.getMoney()), 100, 230, p);
        }

        //Draw progression bar
        int strokeWidth = 10;
        p.setColor(Color.WHITE);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(strokeWidth);
        canvas.drawRoundRect(600, 20, 600 + canvas.getWidth()/3, 110, 40, 40, p);
        p.setColor(getResources().getColor(R.color.progress_bar));
        p.setStyle(Paint.Style.FILL);
        canvas.drawRoundRect(600 + strokeWidth, 20 + strokeWidth, 600 + (canvas.getWidth() / 3 / (w.getScoreMAX() / w.getCurrentScore())) - strokeWidth, 110 - strokeWidth, 40, 40, p);
    }


    @Override
    public void update(Observable observable, Object o) {
        if(observable.equals(ta)) {
            animate();
        }
        else if(observable.equals(tg)) {
            game();
        }

        //call canvas onDraw function
        postInvalidate();
    }

    //draw a bitmap
    public void draw_entity(Canvas canvas,  Bitmap bm,float x,float y){
        canvas.drawBitmap(bm, x,y, p);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        return gd.onTouchEvent(event);
    }

    public ViewPropertyAnimator animate(){
        //change character image
        w.getC().nextImage();
        if(w.getC().getLife() <= 0 && w.getC().endAnim()){
            boolean win = true;
            if(player.isDino()){
                win = false;
            }
            deathMedia.start();
            sc.send("end_game",sc.getId());
            sc.deleteId();
            listener.gameEnded(win);
        }

        for (int i = 0; i < w.lengthObstacle();i++){
            if(w.getObstacles(i) instanceof Eagle){
                ((Eagle) w.getObstacles(i)).nextImage();
            } else if(w.getObstacles(i) instanceof Star){
                ((Star) w.getObstacles(i)).nextImage();
            }
        }
        //animate coin
        if(player.getInvicible()>0){
            star.nextImage();
        }

        return null;
    }
    public void game(){
        //move bg
        w.move_bg(width);

        //apply gravity on character
        w.getC().gravity(w.getGravity(),w.getMaxY());

        // random star
        if(player.getInvicible()<= 0 && new Random().nextInt(1000) == 1){
            // ajout obstacle star
            sc.send("new_obstacles",sc.getId(),"Star-"+Math.random());
        }
        // invicible
        if(player.getInvicible()>0){
            player.addInvicible(-cd_thread);
        }

        //cd obstacles
        player.addCurrent_cd_obstacle(cd_thread);
        if(player.getCurrent_cd_obstacle() >= player.getCd_obstacle()){
            if(listener != null) {
                listener.resetColorButton();
            }
        }
        if(player.getCurrent_cd_flying_obstacle() >= player.getCd_obstacle()){
            if(listener != null) {
                listener.resetColorFlyingButton();
            }
        }
        if(player.isPowerAvailable()){
            Obstacle.resetSpeed();
            if(listener != null) {
                listener.resetColorPowerButton();
            }
        }else{
            if(listener != null) {
                listener.changeColorPowerButton();
            }
        }

        // cd blind
        player.addCurren_blind(-cd_thread);


        //argent
        player.incrMoney(1);

        //progression
        w.setCurrentScore((float) (w.getCurrentScore() + 0.5));
        if(w.getCurrentScore() >= w.getScoreMAX()){
            boolean win = true;
            if(player.isDino()){
                win = false;
            }
            sc.send("end_game",sc.getId());
            sc.deleteId();
            listener.gameEnded(!win);
        }

        //move obstacles
        for (int i = 0; i < w.lengthObstacle();i++){
            if(w.getObstacles(i).moveObstacle()){
                w.removeObstacle(i);
            }
        }

        //jump section
        w.getC().addCurrentCdJump(cd_thread);
        //character jump while the half of the animation time
        if(w.getC().getCurrentCdJump() < w.getC().getCd_jump()/2){
            w.getC().jump();
        }
        //reset double jump
        if(w.getC().getCurrentCdJump() >= w.getC().getCd_jump()){
            w.getC().setDoubleJump(false);
        }
        //collision detection
        for (int i = 0; i < w.lengthObstacle();i++){
            if(!w.getObstacles(i).isTouchedPlayer() && collision(w.getObstacles(i),w.getC().getX(),w.getC().getY(),w.getC().getWidth())){
                if(w.getObstacles(i) instanceof Star){
                    starMedia.start(); //sound
                    player.setInvicible(player.getCd_invicible());
                } else if(player.isDino() && player.getInvicible()<=0) {
                    if(w.getC().getLife() == 1) {
                        deathMedia.start();
                    } else {
                        ouchMedia.start(); //sound
                    }
                    sc.send("life_lost", sc.getId());
                }
                w.getObstacles(i).touchedPlayer();
            }
        }
    }

    public void releaseMedias() {
        jumpMedia.release();
        starMedia.release();
        ouchMedia.release();
        deathMedia.release();
        boltMedia.release();
        inkMedia.release();
    }

    private boolean collision(Obstacle o,float x ,float y,float width) {
        return Math.sqrt((x-o.getX())*(x-o.getX())+(y-o.getY())*(y-o.getY())) <= width/2;
    }

    public void doubleJump() {
            w.getC().resetCurrentRun();
            w.getC().setCurrentCdJump(0);
            w.getC().setDoubleJump(true);

            jumpMedia.start();
    }

    public void singleJump() {
        if(!w.getC().isJumping()){
            w.getC().resetCurrentRun();
            w.getC().setCurrentCdJump(0);
            jumpMedia.start();
            w.getC().setJump_force((int)(0.18  * w.getSize())); 
        }
    }

    public void jump(){
        if(w.getC().getCurrentCdJump() >= w.getC().getCd_jump()){
            singleJump();
        }else if(w.getC().getCurrentCdJump() <= w.getC().getCd_jump() && !w.getC().getDoubleJump()){
            doubleJump();
        }
    }

    public void addObstacle(String obstacles){
        String n[] = obstacles.split("-");
        if(n[0].equals("Cactus")){
            w.addObstacle(new Cactus(width-200,w.getMaxY(),w.getSize()));
            player.incrMoney(-Obstacle.tab_price[1]);
        }else if(n[0].equals("Eagle")){
            w.addObstacle(new Eagle(width, (float) (Math.floor(Double.parseDouble(n[1]) * (w.getMaxY()-200 - w.getMaxY()/3 + 1)) + w.getMaxY()/3),w.getSize()));
            player.incrMoney(-Obstacle.tab_price[2]);
        } else if(n[0].equals("Star")) {
            w.addObstacle(new Star(width, (float) (Math.floor(Double.parseDouble(n[1]) * (w.getMaxY()-200 - w.getMaxY()/3 + 1)) + w.getMaxY()/3),w.getSize()));
        } else{
            w.addObstacle(new Rock(width-200,w.getMaxY()+50,w.getSize()));
            player.incrMoney(-Obstacle.tab_price[0]);
        }
    }
    public void addPower(String power) {
        if(power.equals("bolt")){
            Obstacle.increaseSpeed();
            player.setCurrent_cd_power_bolt();
            player.incrMoney(-Player.power_price[1]);
            boltMedia.start();
        } else {
            player.setCurrent_blind(3000);
            player.setCurrent_cd_power_bolt();
            player.incrMoney(-Player.power_price[0]);
            inkMedia.start();
        }
    }
    public World getWorld(){return w;}
}

